#!/usr/bin/env bash
# ADB Multi-Target Watchdog for Pixel 10 Pro XL

TARGETS=("127.0.0.1:5555" "10.66.66.5:5555")

echo "[$(date)] Starting ADB keepalive watchdog..."

while true; do
    CONNECTED=0
    for TARGET in "${TARGETS[@]}"; do
        STATE=$(adb -s "$TARGET" get-state 2>/dev/null)
        if [ "$STATE" = "device" ]; then
            CONNECTED=1
            break
        fi
    done

    if [ "$CONNECTED" -eq 0 ]; then
        if ss -tln | grep -q ":5555 "; then
            echo "[$(date)] Detected active SSH reverse tunnel on port 5555. Connecting..."
            adb connect 127.0.0.1:5555 >/dev/null 2>&1
        fi

        RECENT_HS=$(wg show wg0 latest-handshakes 2>/dev/null | grep "IgEQxFS/XT+tDr0TwhKTGDfdKfMJE2xH3zN267zNRnc=" | awk '{print $2}')
        NOW=$(date +%s)
        if [ -n "$RECENT_HS" ] && [ "$RECENT_HS" -gt 0 ] && [ $((NOW - RECENT_HS)) -lt 180 ]; then
            echo "[$(date)] Detected recent WireGuard handshake for 10.66.66.5. Connecting..."
            adb connect 10.66.66.5:5555 >/dev/null 2>&1
        fi
    fi
    sleep 5
done
