#!/usr/bin/env bash
# /usr/local/bin/adb-autoconnect.sh
# Intelligent ADB Auto-Connect Watchdog Daemon
# Prioritizes WireGuard direct connection (10.66.66.5:5555) with fallback to Router LAN (192.168.1.71:5555).
# Prevents dual-connection conflict and eliminates router polling.

WG_TARGET="10.66.66.5:5555"
LAN_TARGET="192.168.1.71:5555"

echo "[ADB Watchdog] Starting ADB server..."
adb start-server

while true; do
    # Check if WireGuard direct target is connected
    if adb devices | grep -E "^${WG_TARGET}[[:space:]]+device$" >/dev/null 2>&1; then
        # WireGuard connection is active and healthy.
        # Ensure LAN target is disconnected to prevent dual-device conflict
        if adb devices | grep -E "^${LAN_TARGET}[[:space:]]+" >/dev/null 2>&1; then
            echo "[ADB Watchdog] WireGuard connection active. Disconnecting redundant LAN connection..."
            adb disconnect "$LAN_TARGET" >/dev/null 2>&1
        fi
        sleep 5
        continue
    fi

    # Clean up offline states
    if adb devices | grep -E "^${WG_TARGET}[[:space:]]+offline" >/dev/null 2>&1; then
        echo "[ADB Watchdog] Device $WG_TARGET is offline. Disconnecting..."
        adb disconnect "$WG_TARGET" >/dev/null 2>&1
    fi
    if adb devices | grep -E "^${LAN_TARGET}[[:space:]]+offline" >/dev/null 2>&1; then
        echo "[ADB Watchdog] Device $LAN_TARGET is offline. Disconnecting..."
        adb disconnect "$LAN_TARGET" >/dev/null 2>&1
    fi

    # Attempt WireGuard connection first
    timeout 3 adb connect "$WG_TARGET" >/dev/null 2>&1 || true

    # If WireGuard connected successfully, loop immediately
    if adb devices | grep -E "^${WG_TARGET}[[:space:]]+device$" >/dev/null 2>&1; then
        echo "[ADB Watchdog] Successfully connected via WireGuard ($WG_TARGET)"
        sleep 5
        continue
    fi

    # Fallback to LAN target only if WireGuard is not active and LAN is not already connected
    if ! adb devices | grep -E "^${LAN_TARGET}[[:space:]]+device$" >/dev/null 2>&1; then
        timeout 3 adb connect "$LAN_TARGET" >/dev/null 2>&1 || true
    fi

    sleep 5
done
