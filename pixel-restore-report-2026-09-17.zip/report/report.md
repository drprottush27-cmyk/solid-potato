# Pixel ADB over WireGuard — Restore Report (2026-09-17)

> **SECURITY NOTICE — READ FIRST**
> - This report itself is **safe to share**: no private or preshared keys appear.
> - The **`wireguard-config/` folder in this archive contains REAL private keys
>   and preshared keys** (server + device client configs). Treat it like a key.
> - Transfer this archive **only over SSH/SCP/SFTP** to the VPS (`scp
>   root@187.53.132.80:/root/<archive> .`). Never place it on public storage,
>   chat, email, or a public repo.
> - File permission is `0600` root-only. Preserve that after download
>   (`chmod 600`).
> - After you have the copy you need, consider `rm` the archive on the VPS.
> - Optional extra protection you can apply yourself (do not paste passphrases
>   into chat): re-zip with `zip -P '<your passphrase>'` or `gpg -c`.

---

## 1. What this archive contains

| Path | Content | Secrecy |
| --- | --- | --- |
| `report/01-vps-snapshot.txt` | live `wg show`, routes, ufw, systemd, adb snapshot | Safe |
| `report/report.md` (this file) | full inspection summary | Safe |
| `report/ADB_RESTORE_HANDOFF.md` | restore + Wireless-Debugging migration guide | Safe |
| `firewall-backup/` | ufw status before change + `user.rules` backups | Safe |
| `systemd/` | watchdog / proxy unit files | Safe |
| `scripts/` | `adb-autoconnect.sh`, `adb_keepalive.sh` | Safe |
| `wireguard-config/` | `wg0.conf`, `clients/*.conf`, `*.key` files, QR PNGs | **SECRET** |

## 2. Architecture (as inspected)

- VPS: Hostinger KVM, hostname `srv1947292`, `srv1947292.hstgr.cloud`,
  Ubuntu 24.04.5 LTS, kernel 6.8.0-138-generic.
- Public IP: `187.53.132.80/24` on `eth0` (default via `187.53.132.254`).
- WireGuard: `wg0`, `10.66.66.1/24`, listening UDP `51820`, server public key
  `ktBQDU3YdWoy513UhHyuE8u5QS1ZDimW2RvEv4OjKxU=` (public).
- Peers (public keys + roles, current at snapshot time):

| Role | Tunnel IP | AllowedIPs | Endpoint seen | Handshake |
| --- | --- | --- | --- | --- |
| Home router | 10.66.66.2 | 10.66.66.2/32, 192.168.1.0/24, 192.168.0.0/24 | 103.187.94.110:56948 | healthy (<2 min) |
| iPad | 10.66.66.3 | 10.66.66.3/32 | via router | healthy |
| iPhone 1 | 10.66.66.4 | 10.66.66.4/32 | none (offline) | none |
| **Pixel 10 Pro XL** | **10.66.66.5** | 10.66.66.5/32 | public IP, keepalive 25s | healthy (<2 min) |
| iPhone 2 | 10.66.66.6 | 10.66.66.6/32 | via router | healthy |

- ADB: platform-tools 34.0.4 (`adb`), device `10.66.66.5:5555  device`
  (Pixel 10 Pro XL, RSA authorized, over the tunnel).
- Docker present (Kasm, traefik, ws-scrcpy, etc.) — untouched.

## 3. Firewall (VPS, ufw)

- Default incoming DROP; forward ALLOW. `net.ipv4.ip_forward = 1`.
- Public inbound: `22/tcp`, `80/tcp`, `443/tcp`, `51820/udp` (v4+v6).
- WireGuard-only inbound: `8088/tcp`, `10.66.66.1:8443/8440/3389/8123` on wg0.
- **Change made during restore:** removed vestigial
  `5555/tcp ALLOW IN 172.16.0.0/12`. No inbound ADB port remains on the VPS.
  Rollback: `ufw allow from 172.16.0.0/12 to any port 5555 proto tcp` or restore
  `firewall-backup/`.
- ADB is client-outbound only on the VPS.

## 4. Routes (existing, preserved)

- `10.66.66.0/24 dev wg0`, `192.168.0.0/24 dev wg0`, `192.168.1.0/24 dev wg0`.
- No routes were added/changed during this restore.

## 5. Services (persisted)

- `wg-quick@wg0` enabled + active. Watchdogs `adb-autoconnect`,
  `adb-keepalive` enabled + active. `scrcpy-wireguard.{service,socket}` enabled
  + active (proxy `10.66.66.1:8123` → `127.0.0.1:8123`).
- `tg-adb-dashboard` active (backend `127.0.0.1:8090`).

## 6. ADB restore status

- Legacy tunnel path `10.66.66.5:5555` → `device` (working, auto-healing).
- Wireless Debugging setting enabled on device (`adb_wifi_enabled=1`) but TLS
  listener idle (`service.adb.tls.port` empty) — pairing pending (needs Pixel
  in hand). See `ADB_RESTORE_HANDOFF.md` for exact steps.

## 7. Known gaps

- VPS → home LAN `192.168.1.0/24` not routable (router drops forwarded tunnel
  traffic). Not required for ADB. Router-side fix documented in handoff.
- Legacy `adb tcpip 5555` on Pixel persists until reboot/adbd restart.
- iPhone peer `10.66.66.4` offline (no handshake).

## 8. Rollback of this restore

```bash
# Firewall rule restoration
ufw allow from 172.16.0.0/12 to any port 5555 proto tcp

# Boot-enablement rollback
systemctl disable adb-keepalive scrcpy-wireguard scrcpy-wireguard.socket

# Delete this archive (after safe copy made)
rm /root/pixel-restore-report-*.zip
```