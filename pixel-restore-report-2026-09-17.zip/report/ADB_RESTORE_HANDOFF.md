# Pixel ADB over WireGuard — Restore / Handoff Guide

> **Security model**
> - This file contains **no secrets**. Private and preshared keys live only in
>   `/etc/wireguard/` (mode `0600`, root-only). Do not inline or commit them.
> - ADB is **never** exposed to the public internet. All ADB traffic rides the
>   WireGuard tunnel to the Pixel's WireGuard IP.
> - Android RSA authorization is never bypassed. The device must show state
>   `device`, never `unauthorized`.
> - Pairing codes and 6-digit codes are **never** pasted into chat/files — the
>   operator enters them interactively at the VPS terminal (`adb pair` prompt).

## 1. Architecture

| Role | Address | Notes |
| --- | --- | --- |
| VPS (Hostinger, Ubuntu 24.04, host `srv1947292`) | `187.53.132.80` / `10.66.66.1/24` | ADB client. `srv1947292.hstgr.cloud` |
| Home router WireGuard peer | `10.66.66.2/32`, route `192.168.1.0/24` | Site/lan peer, full-tunnel client config |
| **Pixel 10 Pro XL** (`mustang`) WG peer | `10.66.66.5/32` | Direct client, PersistentKeepalive 25, appears as peer pubkey `IgEQxFSX...zNRnc=` |
| Grant LAN IP of Pixel (not routed) | `192.168.1.71` | LAN fallback is currently non-routable from VPS (router drops) |
| Tunnel subnet | `10.66.66.0/24` | wg0 on UDP `51820` |

WireGuard interface: `wg0`, config `/etc/wireguard/wg0.conf`, managed by
`systemd` unit `wg-quick@wg0.service`. Server public key:
`ktBQDU3YdWoy513UhHyuE8u5QS1ZDimW2RvEv4OjKxU=` (public, for key verification only).

## 2. Services that must be running (VPS)

| Unit | Purpose |
| --- | --- |
| `wg-quick@wg0.service` | WireGuard tunnel |
| `adb-autoconnect.service` | Watchdog: prefers `10.66.66.5:5555`, LAN fallback `192.168.1.71:5555` |
| `adb-keepalive.service` | Watchdog: reconnects on handshake / SSH reverse-tunnel port 5555 |
| `scrcpy-wireguard.service` + `.socket` | ws-scrcpy (port 8123) bound to wg0/loopback only |
| `tg-adb-dashboard.service` | Telegram ADB dashboard, backend on `127.0.0.1:8090` |

Diagnostics:
```bash
systemctl --no-pager --type=service | grep -E 'wg|adb|scrcpy|tg-adb'
wg show
adb devices -l
```

## 3. Quick health check (VPS)

```bash
wg show                              # handshakes fresh (< ~3 min = healthy)
ping -c3 -W2 10.66.66.5              # Pixel tunnel: expect 0% loss, ~60ms RTT
adb devices -l                       # expect: 10.66.66.5:5555 device (Pixel 10 Pro XL)
ss -tlnp | grep 5555                 # expect NO listener (ADB client mode only)
ufw status                           # NO rule may reference port 5555
```

Expected stock output for `wg show` (keys hidden by default): 5 peers; the Pixel
peer is the one with AllowedIPs `10.66.66.5/32` and keepalive. Handshake seconds
should be recent.

## 4. Restore procedure

1. Start tunnel: `systemctl start wg-quick@wg0` (enabled, survives reboot).
2. ADB server: `adb start-server`.
3. Watchdogs reconnect automatically; or manually:
   ```bash
   adb connect 10.66.66.5:5555
   adb devices -l                     # must show "device", not "unauthorized"
   ```
4. If state is `unauthorized`: re-accept the RSA fingerprint on the Pixel (this
   is correct and required — never bypass).
5. `adb reconnect` is the graceful bounce; verify it returns to `device`.

## 5. Wireless Debugging migration (when the Pixel is in hand)

Phone is currently in legacy `adb tcpip` mode (`service.adb.tcp.port=5555`) and
Wireless Debugging is enabled in settings (`adb_wifi_enabled=1`) but its TLS
listener is idle (`service.adb.tls.port` is empty). Migration steps:

1. **On the Pixel:** Settings → System → Developer options → **Wireless
   debugging** → On.
2. Tap **Pair device with pairing code**. Read the two values on screen:
   - Pairing IP:port (e.g. `10.66.66.5:37xxx`)
   - 6-digit pairing code.
3. **On the VPS terminal** (operator MUST type the code themselves — interactive,
   never pasted):
   ```bash
   adb pair 10.66.66.5:<PAIR_PORT>     # then type the 6-digit code at the prompt
   adb connect 10.66.66.5:<CONNECT_PORT>   # USE the "IP address & Port" line on the Pixel
   adb devices -l                      # accept RSA prompt on the Pixel if shown
   ```
4. Confirm TLS path is live: `adb -s 10.66.66.5:<CONNECT_PORT> shell getprop service.adb.tls.port`
   → the port should echo back; legacy 5555 can then be demoted to bootstrap-only.
5. Update the watchdog targets (`/usr/local/bin/adb-autoconnect.sh`,
   `/root/pixel-stealth/adb_keepalive.sh`) to prefer the discovered TLS port,
   falling back to `10.66.66.5:5555`.

Notes
- Pairing ports/codes change every time pairing is re-entered; expect re-pairing
  after phone reboots on some builds.
- Do not rely on Wireless Debugging TCP port stability; discover it via
  `getprop service.adb.tls.port` on an already-authorized connection.

## 6. Firewall (VPS, ufw) — current state

Allowed inbound: `22/tcp`, `80/tcp`, `443/tcp`, `51820/udp` (public),
`8088/tcp` on wg0 (Phantom dashboard), `10.66.66.1:8443/8440/3389/8123` on
wg0 (Kasm/XRDP/ws-scrcpy). Default incoming DROP.

**2026-09-17 change (this restore):** removed vestigial
`5555/tcp ALLOW IN 172.16.0.0/12` — nothing listens on 5555 anywhere; the VPS is
client-only for ADB. Rollback:
```bash
sudo ufw allow from 172.16.0.0/12 to any port 5555 proto tcp
```
Backup: `/root/firewall-backup/2026-09-17-pixel-restore/` (rules → `cp
/etc/ufw/user.rules` back over).

## 7. Known gaps / limitations

- **VPS → home LAN is not routable.** Pings/TCP to `10.66.66.2` and
  `192.168.1.71` fail — the home router silently drops forwarded tunnel traffic.
  ADB does not depend on it (Pixel tunnels directly). To fix later, on the home
  router: enable forward `wg0 → LAN (192.168.1.0/24)`, add `AllowedIPs =
  10.66.66.0/24` on the router's peer, and stop dropping ICMP on the tunnel
  interface. (Router-side change only.)
- Legacy `adb tcpip 5555` on the Pixel persists until the phone reboots / adbd
  restarts; it listens on the Pixel's interfaces, including LAN. If the Pixel is
  ever reachable from the public internet this would be a risk — which is why the
  VPS-side firewall never permits inbound ADB and the public face is only 51820/udp.
- `persistentKeepalive` is only on the `10.66.66.5` peer here; routers/mobile
  peers that sit behind NAT rely on their own keepalive (the Pixel's client
  config sets `PersistentKeepalive = 25`).

## 8. Test checklist (post-restore)

- [ ] `wg show wg0 latest-handshakes` — Pixel peer within 0–180 s
- [ ] `ping -c3 10.66.66.5` — 0% loss
- [ ] `adb connect 10.66.66.5:5555` — "already connected"
- [ ] `adb devices -l` — `device`, `Pixel_10_Pro_XL`, transport set
- [ ] `adb reconnect` — returns to `device`
- [ ] restart watchdog: `systemctl restart adb-autoconnect` → still `device`
- [ ] `adb -s 10.66.66.5:5555 shell getprop ro.product.model` → `Pixel 10 Pro XL`