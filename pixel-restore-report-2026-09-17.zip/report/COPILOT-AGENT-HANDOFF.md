# Copilot Agent Handoff — Pixel ADB via WireGuard

> Purpose: let an AI coding agent restore, verify, or troubleshoot remote ADB
> access to a **Pixel 10 Pro XL** from a **Hostinger VPS** through a
> **WireGuard** tunnel.
>
> This document is **public-safe**: it contains no private keys, preshared
> keys, pairing codes, tokens, or account credentials. Secrets live only on the
> VPS in root-only files; you operate on them by **path**, never by content.

---

## 1. Environment snapshot (non-secret, verified 2026-09-17)

| Item | Value |
| --- | --- |
| VPS | `srv1947292.hstgr.cloud` / `187.53.132.80`, Ubuntu 24.04.5, kernel 6.8.0-138-generic, SSH port 22 |
| Tunnel | `wg0` = `10.66.66.1/24`, UDP `51820`; server public key `ktBQDU3YdWoy513UhHyuE8u5QS1ZDimW2RvEv4OjKxU=` |
| Home router peer | `10.66.66.2` (AllowedIPs `10.66.66.2/32`, `192.168.1.0/24`) — **do not depend on it** |
| **Pixel peer** | `10.66.66.5` (AllowedIPs `10.66.66.5/32`, keepalive 25s); peer public key `IgEQxFS/XT+tDr0TwhKTGDfdKfMJE2xH3zN267zNRnc=` |
| ADB target (legacy TCP over tunnel) | `10.66.66.5:5555` |
| Other peers | iPad `.3`, iPhone `.4` (offline), iPhone 2 `.6` — leave untouched |
| VPS inbound FW (ufw, default DROP) | public: `22/80/443/tcp`, `51820/udp`; wg0-only: `8088`, `8443`, `8440`, `3389`, `8123` |
| Persistence | `wg-quick@wg0`, `adb-autoconnect`, `adb-keepalive`, `scrcpy-wireguard.{service,socket}`, `tg-adb-dashboard` |

## 2. Hard constraints (never violate)

1. **Secrets.** Never print, request, guess, or write into files/chat: WG
   `PrivateKey`/`PresharedKey`, ADB RSA keys, pairing codes, SSH credentials,
   Kasm credentials, wallet material. Read-only access by path:
   `/etc/wireguard/*` (root `0600`), `/root/.android/adbkey*`.
2. **No public exposure.** Never open ADB or control ports to the internet.
   ADB-capable listeners stay on `10.66.66.0/24` or loopback. Do **not** add a
   ufw rule for `5555`; do **not** add host-port forwards or DNAT for ADB.
3. **Pairing codes are human-only.** `adb pair` prompts for a 6-digit code that
   the **operator** types at a VPS terminal. You never obtain, store, or
   transmit it. If no human is present, do not attempt pairing.
4. **Never bypass Android RSA authorization.** A device in state
   `unauthorized` must be re-authorized on the phone screen. `device` state is
   the only good state.
5. **Preserve.** Do not touch other WG peers, Docker/Kasm/Traefik services, or
   existing ufw rules unless explicitly asked. Back up before editing:
   `cp <file> <file>.bak.$(date +%Y%m%d_%H%M%S)`.
6. **Show before apply.** Present the exact commands you intend to run and
   their effect (which host: VPS / router / Pixel) before executing anything
   destructive or persistent.
7. **ADB role.** The VPS is a pure ADB *client*. No process here should listen
   on `5555`. The `5555` listener is adbd on the **Pixel**, reached only
   through its tunnel. If you see inbound `5555` permitted anywhere on the VPS,
   flag it — it is a violation.

## 3. Playbook A — verify current health (read-only, on VPS)

```bash
wg show wg0                      # Pixel peer handshake < 180s = healthy
wg show wg0 latest-handshakes
ping -c3 -W2 10.66.66.5          # expect 0% loss (~60 ms)
adb devices -l                   # expect: 10.66.66.5:5555 device (Pixel 10 Pro XL)
systemctl is-active wg-quick@wg0 adb-autoconnect adb-keepalive
ufw status numbered              # confirm NO rule references port 5555
ss -tln | grep 5555 || echo "no local 5555 listener (correct)"
```

Health verdict: handshake fresh **and** `adb devices` shows `device` →
**already restored; make no changes.**

## 4. Playbook B — restore from cold (VPS)

1. `systemctl start wg-quick@wg0` (tunnel).
2. `systemctl start adb-autoconnect adb-keepalive` (watchdogs) or run manually:
   ```bash
   adb start-server
   adb connect 10.66.66.5:5555   # may already report "already connected"
   adb devices -l                # 10.66.66.5:5555 device
   ```
3. If `unauthorized`: tell the operator to tap **Allow** (RSA) on the Pixel.
4. If the tunnel itself is down for a peer, check:
   `wg show wg0 | grep -A4 IgEQxF` and confirm the peer's client still has
   `PersistentKeepalive = 25` and endpoint `187.53.132.80:51820`
   (config: `/etc/wireguard/clients/android.conf`). **Show** before editing.

## 5. Playbook C — Wireless Debugging migration (operator present)

1. Phone: Settings → System → Developer options → **Wireless debugging** → On;
   read "Pair with pairing code" (IP:PAIR_PORT + 6-digit code).
2. Give the operator exactly:
   ```bash
   adb pair 10.66.66.5:<PAIR_PORT>      # operator types the code at the prompt
   adb connect 10.66.66.5:<CONNECT_PORT>
   adb devices -l
   ```
3. Verify: `adb -s 10.66.66.5:<CONNECT_PORT> shell getprop service.adb.tls.port`
   echoes the port (TLS transport live).
4. Do **not** hardcode PAIR/CONNECT ports — they are ephemeral and reset on
   re-pair/reboot. Re-pairing is expected and normal.

## 6. Playbook D — fault triage map

| Symptom | Likely cause | First action |
| --- | --- | --- |
| No traffic / `latest-handshakes` 0 | Pixel WG client off / phone asleep | Ping `10.66.66.5`; ask operator to check phone tunnel |
| `adb devices` empty | adb server died (rare; watchdogs cover) | `adb start-server`; check watchdog services |
| State `unauthorized` | RSA revoked / new adbd key | Operator re-authorizes on phone (never bypass) |
| `10.66.66.5` unreachable but router peer fine | Pixel client config or device VPN off | Inspect `/etc/wireguard/clients/android.conf` (paths only) |
| LAN target `192.168.1.71:5555` unreachable | Known limitation: router drops tunnel-forwarded LAN traffic | **Expected.** Use `10.66.66.5` directly |

## 7. Known limitations (trust these)

- VPS → home LAN `192.168.1.0/24` **is not routable** (router-side drop). All
  Pixel ADB work must use the direct tunnel IP `10.66.66.5`.
- Legacy `adb tcpip 5555` stays active on the Pixel until reboot/adbd restart —
  fine because it is only reachable via the tunnel.
- iPhone peer `10.66.66.4` has no recent handshake (offline); not an error.

## 8. Rollback (if a change is ever needed)

```bash
systemctl disable adb-keepalive scrcpy-wireguard scrcpy-wireguard.socket   # re-enable with 'enable'
ufw allow from 172.16.0.0/12 to any port 5555 proto tcp                    # restore removed rule (not recommended)
# restore any edited config: cp <file>.bak.<ts> <file> && systemctl restart wg-quick@wg0
```